# Solax Monitor App

App Android (Kotlin) que muestra en tiempo real los datos de tu instalación
solar, leyendo de Firebase Realtime Database por HTTP normal (sin SDK de
Firebase, sin `google-services.json`).

## Por qué así
Esto permite compartir un único APK con quien quieras: cada persona monta
su propio ESP32 + su propio proyecto Firebase, y simplemente escribe SU
URL en la app la primera vez que la abre. Nada de tu proyecto queda
incrustado en el APK.

Funciona porque la URL de tu Realtime Database + `/datos.json` al final es
un endpoint REST de lectura pública (mientras las reglas tengan
`".read": true`, como se indica más abajo).

## Pasos para dejarla funcionando

1. **Abrir en Android Studio:**
   - `File → Open` → selecciona la carpeta `SolaxMonitorApp`.
   - Deja que sincronice Gradle.

2. **Compilar y ejecutar** (o generar el APK con `Build → Build APK(s)`).

3. **Primera vez que se abre la app:** te pedirá la URL de tu base de
   datos. Pega la misma que pusiste en `FIREBASE_HOST` dentro del `.ino`
   del ESP32 (ej. `https://tu-proyecto-default-rtdb.europe-west1.firebasedatabase.app`),
   **sin** el secreto/token, solo la URL. Se guarda en el móvil y no hay
   que volver a escribirla.
   - Si más adelante quieres cambiarla (por ejemplo, para ver los datos de
     otra instalación), usa el menú de tres puntos → "Cambiar servidor".

4. **Reglas de la base de datos** (en Firebase Console → Realtime Database
   → pestaña "Reglas" → Publicar):
   ```json
   {
     "rules": {
       "datos": {
         ".read": true,
         ".write": false
       }
     }
   }
   ```
   El ESP32 escribe usando el "Database Secret" (que se salta las reglas
   de escritura), así que esto solo controla quién puede LEER. Con
   `.read: true`, cualquiera con la URL puede ver los datos — para más
   privacidad se puede añadir Firebase Authentication más adelante.

## Compartir la app con otra persona
Solo tienes que pasarle el `.apk` generado (`Build → Build APK(s)`, queda
en `app/build/outputs/apk/debug/app-debug.apk`). Esa persona necesita:
1. Su propio ESP32 con el firmware, apuntando a su propio proyecto Firebase.
2. Abrir la app e introducir la URL de SU base de datos la primera vez.

No necesita tu `google-services.json` ni ningún dato tuyo — la app es
genérica, cada quien la apunta a su propio servidor.

## Campos que muestra
Todos los confirmados del protocolo: voltajes, corrientes y potencia por
fase (R/S/T), frecuencia, generación (hoy/mensual/total), exportación
(hoy/mensual/total), importación (hoy/mensual/total), temperaturas
(máxima/media/mínima/secundaria), potencia nominal, potencia neta de red,
potencia fotovoltaica y potencia de consumo de la casa (estas dos últimas
derivadas, ver comentarios en el firmware).
