package com.solax.monitor

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/*
  Esta app NO usa el SDK de Firebase ni necesita google-services.json.
  Hace una peticion HTTP normal a la URL de tu Realtime Database +
  "/datos.json" (endpoint REST de lectura publica, gracias a que en las
  reglas de Firebase se dejo ".read": true). Por eso se puede compartir el
  mismo APK con cualquiera: cada persona escribe SU URL la primera vez que
  abre la app, sin que quede nada de tu proyecto incrustado en el APK.
*/

class MainActivity : AppCompatActivity() {

    private lateinit var swipeRefresh: SwipeRefreshLayout
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val INTERVALO_MS = 5000L
    private var poloEnMarcha = false

    private lateinit var prefs: android.content.SharedPreferences

    // Cabecera / hero
    private lateinit var tvNombrePlanta: TextView
    private lateinit var tvFecha: TextView
    private lateinit var tvPotenciaPvHero: TextView
    private lateinit var tvPotenciaNominal: TextView
    private lateinit var tvUltimaActualizacion: TextView

    // Filas de la tarjeta "Red electrica"
    private lateinit var filaVoltajes: FilaDato
    private lateinit var filaCorrientes: FilaDato
    private lateinit var filaPotenciasFase: FilaDato
    private lateinit var filaFrecuencias: FilaDato

    // Cajas de estadistica (icono+valor+etiqueta)
    private lateinit var statGenHoy: StatBox
    private lateinit var statGenMensual: StatBox
    private lateinit var statGenTotal: StatBox
    private lateinit var statExpHoy: StatBox
    private lateinit var statExpMensual: StatBox
    private lateinit var statExpTotal: StatBox
    private lateinit var statTempMax: StatBox
    private lateinit var statTempMedia: StatBox
    private lateinit var statTempMin: StatBox
    private lateinit var statTempSec: StatBox

    private class FilaDato(root: View) {
        val label: TextView = root.findViewById(R.id.tvLabel)
        val value: TextView = root.findViewById(R.id.tvValue)
        fun set(etiqueta: String, valor: String) {
            label.text = etiqueta
            value.text = valor
        }
    }

    private class StatBox(root: View) {
        val value: TextView = root.findViewById(R.id.tvStatValue)
        val label: TextView = root.findViewById(R.id.tvStatLabel)
        fun set(etiqueta: String, valor: String) {
            label.text = etiqueta
            value.text = valor
        }
    }

    private fun tituloTarjeta(rootId: Int, iconoRes: Int, texto: String) {
        val root = findViewById<View>(rootId)
        root.findViewById<ImageView>(R.id.ivCardIcon).setImageResource(iconoRes)
        root.findViewById<TextView>(R.id.tvCardTitulo).text = texto
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("solax_prefs", Context.MODE_PRIVATE)

        swipeRefresh = findViewById(R.id.swipeRefresh)
        tvNombrePlanta = findViewById(R.id.tvNombrePlanta)
        tvFecha = findViewById(R.id.tvFecha)
        tvPotenciaPvHero = findViewById(R.id.tvPotenciaPvHero)
        tvPotenciaNominal = findViewById(R.id.tvPotenciaNominal)
        tvUltimaActualizacion = findViewById(R.id.tvUltimaActualizacion)

        filaVoltajes = FilaDato(findViewById(R.id.filaVoltajes))
        filaCorrientes = FilaDato(findViewById(R.id.filaCorrientes))
        filaPotenciasFase = FilaDato(findViewById(R.id.filaPotenciasFase))
        filaFrecuencias = FilaDato(findViewById(R.id.filaFrecuencias))

        statGenHoy = StatBox(findViewById(R.id.statGenHoy))
        statGenMensual = StatBox(findViewById(R.id.statGenMensual))
        statGenTotal = StatBox(findViewById(R.id.statGenTotal))
        statExpHoy = StatBox(findViewById(R.id.statExpHoy))
        statExpMensual = StatBox(findViewById(R.id.statExpMensual))
        statExpTotal = StatBox(findViewById(R.id.statExpTotal))
        statTempMax = StatBox(findViewById(R.id.statTempMax))
        statTempMedia = StatBox(findViewById(R.id.statTempMedia))
        statTempMin = StatBox(findViewById(R.id.statTempMin))
        statTempSec = StatBox(findViewById(R.id.statTempSec))

        tituloTarjeta(R.id.tituloRed, R.drawable.ic_grid, "Red eléctrica")
        tituloTarjeta(R.id.tituloGeneracion, R.drawable.ic_sun, "Generación")
        tituloTarjeta(R.id.tituloExportacion, R.drawable.ic_export, "Exportación a red")
        tituloTarjeta(R.id.tituloTemp, R.drawable.ic_thermo, "Temperatura del inversor")

        swipeRefresh.setOnRefreshListener { consultarAhora() }

        if (obtenerUrlBase() == null) {
            pedirUrlServidor(esPrimeraVez = true)
        } else {
            iniciarPolling()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Cambiar servidor")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == 1) {
            pedirUrlServidor(esPrimeraVez = false)
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun obtenerUrlBase(): String? = prefs.getString("firebase_host", null)

    private fun pedirUrlServidor(esPrimeraVez: Boolean) {
        val input = EditText(this)
        input.hint = "https://tu-proyecto-default-rtdb.region.firebasedatabase.app"
        obtenerUrlBase()?.let { input.setText(it) }

        AlertDialog.Builder(this)
            .setTitle("URL de tu base de datos Firebase")
            .setMessage("Pega aqui la URL de tu Realtime Database (la misma que pusiste en el ESP32, sin el token/secreto).")
            .setView(input)
            .setCancelable(!esPrimeraVez)
            .setPositiveButton("Guardar") { _, _ ->
                var url = input.text.toString().trim()
                if (url.endsWith("/")) url = url.dropLast(1)
                if (url.isNotEmpty()) {
                    prefs.edit().putString("firebase_host", url).apply()
                    iniciarPolling()
                } else if (esPrimeraVez) {
                    pedirUrlServidor(true)
                }
            }
            .apply { if (!esPrimeraVez) setNegativeButton("Cancelar", null) }
            .show()
    }

    private fun iniciarPolling() {
        if (poloEnMarcha) return
        poloEnMarcha = true
        consultarAhora()
        handler.postDelayed(pollingRunnable, INTERVALO_MS)
    }

    private val pollingRunnable = object : Runnable {
        override fun run() {
            consultarAhora()
            handler.postDelayed(this, INTERVALO_MS)
        }
    }

    private fun consultarAhora() {
        val base = obtenerUrlBase() ?: return
        executor.execute {
            try {
                val url = URL("$base/datos.json")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val codigo = conn.responseCode
                if (codigo == 200) {
                    val texto = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    val json = JSONObject(texto)
                    handler.post {
                        pintarDatos(json)
                        swipeRefresh.isRefreshing = false
                    }
                } else {
                    conn.disconnect()
                    handler.post {
                        swipeRefresh.isRefreshing = false
                        Toast.makeText(this, "Error del servidor (código $codigo)", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                handler.post {
                    swipeRefresh.isRefreshing = false
                    Toast.makeText(this, "No se pudo conectar: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun d(s: JSONObject, campo: String): Double = if (s.has(campo) && !s.isNull(campo)) s.optDouble(campo, 0.0) else 0.0

    private fun pintarDatos(s: JSONObject) {
        tvNombrePlanta.text = if (s.has("nombrePlanta")) s.optString("nombrePlanta") else "--"
        tvFecha.text = if (s.has("fecha")) s.optString("fecha") else "--"

        tvPotenciaPvHero.text = "%.0f W".format(d(s, "potenciaFotovoltaica"))
        tvPotenciaNominal.text = "Nominal: %.0f W".format(d(s, "potenciaNominalInversor"))

        filaVoltajes.set("Voltaje R / S / T", "%.1f / %.1f / %.1f V".format(d(s,"voltajeR"), d(s,"voltajeS"), d(s,"voltajeT")))
        filaCorrientes.set("Corriente R / S / T", "%.1f / %.1f / %.1f A".format(d(s,"corrienteR"), d(s,"corrienteS"), d(s,"corrienteT")))
        filaPotenciasFase.set("Potencia R / S / T", "%.0f / %.0f / %.0f W".format(d(s,"potenciaR"), d(s,"potenciaS"), d(s,"potenciaT")))
        filaFrecuencias.set("Frecuencia R / S / T", "%.2f / %.2f / %.2f Hz".format(d(s,"frecuenciaR"), d(s,"frecuenciaS"), d(s,"frecuenciaT")))

        statGenHoy.set("Hoy", "%.2f kWh".format(d(s, "generacionHoy")))
        statGenMensual.set("Mensual", "%.1f kWh".format(d(s, "generacionMensual")))
        statGenTotal.set("Total", formatearEnergia(d(s, "generacionTotal")))

        statExpHoy.set("Hoy", "%.2f kWh".format(d(s, "exportacionHoy")))
        statExpMensual.set("Mensual", "%.2f kWh".format(d(s, "exportacionMensual")))
        statExpTotal.set("Total", formatearEnergia(d(s, "exportacionTotal")))

        statTempMax.set("Máxima", "%.0f°C".format(d(s, "temperaturaMaxima")))
        statTempMedia.set("Media", "%.1f°C".format(d(s, "temperaturaMedia")))
        statTempMin.set("Mínima", "%.0f°C".format(d(s, "temperaturaMinima")))
        statTempSec.set("Sonda 2", "%.0f°C".format(d(s, "temperaturaSecundaria")))

        if (s.has("timestamp")) {
            val ts = s.optLong("timestamp", 0L)
            if (ts > 0) {
                val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
                tvUltimaActualizacion.text = "Última actualización: " + sdf.format(Date(ts * 1000))
            }
        }
    }

    // Igual que en el firmware: MWh si son >=1000 kWh, si no kWh
    private fun formatearEnergia(kwh: Double): String {
        return if (kwh >= 1000.0) "%.2f MWh".format(kwh / 1000.0) else "%.1f kWh".format(kwh)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(pollingRunnable)
    }
}
